Welcome to Panels 3

Documentation is available at https://www.drupal.org/node/496278
